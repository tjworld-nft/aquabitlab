"""Wikidata（CC0）から、日本の神社・お寺・自然の名所を取り出す。
OpenStreetMap に載っていない社寺を補うために使う（build_all.py が重なりを除く）。
出力:
  raw/wd_shrines.tsv   神社（Q845945 とその下位）
  raw/wd_temples.tsv   仏教寺院（Q5393308 とその下位）
  raw/wd_nature.tsv    滝・洞窟・巨樹・泉（温泉を除く）・天然記念物/名勝の自然物
列: qid lat lon label kana jawiki classes ended（廃絶・廃寺の日付。あれば載せない）
使い方: python3 fetch_wikidata.py"""
import csv, json, time, urllib.parse, urllib.request

EP = 'https://query.wikidata.org/sparql'
UA = 'ryumyaku-map-prototype/0.1 (data build; https://miura-diving.com/)'


def run(q, tries=4):
    url = EP + '?' + urllib.parse.urlencode({'query': q, 'format': 'json'})
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers={'User-Agent': UA, 'Accept': 'application/sparql-results+json'})
            with urllib.request.urlopen(req, timeout=300) as r:
                return json.load(r)['results']['bindings']
        except Exception as e:  # 混んでいるときは待ってやり直す
            print('retry', i, e)
            time.sleep(20 * (i + 1))
    raise SystemExit('wikidata failed')


def val(b, k):
    v = b.get(k, {}).get('value', '')
    return v.replace('http://www.wikidata.org/entity/', '')


BODY = """
  OPTIONAL { ?s rdfs:label ?label FILTER(LANG(?label)='ja') }
  OPTIONAL { ?s wdt:P1814 ?kana }
  OPTIONAL { ?a schema:about ?s ; schema:isPartOf <https://ja.wikipedia.org/> ; schema:name ?jawiki }
  OPTIONAL { ?s wdt:P576 ?end }
"""


def fetch(cls_filter, out, extra=''):
    q = f"""SELECT ?s ?c ?label ?kana ?jawiki (GROUP_CONCAT(DISTINCT ?t;separator=' ') AS ?cls) (SAMPLE(?end) AS ?ended) WHERE {{
  {cls_filter}
  ?s wdt:P17 wd:Q17 ; wdt:P625 ?c .
  ?s wdt:P31 ?t .
  {extra}
  {BODY}
}} GROUP BY ?s ?c ?label ?kana ?jawiki"""
    rows = run(q)
    seen = set()
    with open(out, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f, delimiter='\t')
        w.writerow(['qid', 'lat', 'lon', 'label', 'kana', 'jawiki', 'classes', 'ended'])
        for b in rows:
            qid = val(b, 's')
            if qid in seen:
                continue
            c = val(b, 'c')  # Point(lon lat)
            if not c.startswith('Point('):
                continue
            lon, lat = c[6:-1].split()
            seen.add(qid)
            w.writerow([qid, lat, lon, val(b, 'label'), val(b, 'kana'), val(b, 'jawiki'), val(b, 'cls'), val(b, 'ended')[:10]])
    print(out, len(seen))


fetch('?s wdt:P31/wdt:P279* wd:Q845945 .', 'raw/wd_shrines.tsv')
fetch('?s wdt:P31/wdt:P279* wd:Q5393308 .', 'raw/wd_temples.tsv')
# 自然: 滝 / 洞窟 / 巨樹 / 泉（温泉 Q177380 は除く）/ 天然記念物・名勝に指定された自然物
fetch("""{ ?s wdt:P31/wdt:P279* wd:Q34038 . } UNION { ?s wdt:P31/wdt:P279* wd:Q35509 . }
  UNION { ?s wdt:P31/wdt:P279* wd:Q11479807 . } UNION { ?s wdt:P31/wdt:P279* wd:Q124714 . }
  UNION { VALUES ?h { wd:Q23790 wd:Q96207459 } ?s wdt:P1435 ?h . }""",
      'raw/wd_nature.tsv', extra='FILTER NOT EXISTS { ?s wdt:P31/wdt:P279* wd:Q177380 }')
