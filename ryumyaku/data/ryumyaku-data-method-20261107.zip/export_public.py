"""アプリに入れている場所のデータ（assets/shrines.bin.gz）を、そのまま公開用の CSV にする。
OpenStreetMap の Open Database License（ODbL）4.6：取り出して整えたデータベースをアプリに入れて配る以上、
そのデータベース（または作り方）を受け取った人が手にできるようにする。ここでは両方を出す。
出力：../public-data/
  ryumyaku-places-YYYYMMDD.csv.gz   場所（神社・お寺・自然の場所）99,783 か所
  ryumyaku-facts-YYYYMMDD.tsv.gz    Wikidata（CC0）から集めた、まつる神さま・創建など（アプリの「さらに知る」）
  ryumyaku-data-method-YYYYMMDD.zip 作り方（取り出し・照合・まとめのスクリプト）
  README.txt                        ライセンスと列の説明
使い方：python3 export_public.py
"""
import csv, gzip, io, os, re, struct, time, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.join(HERE, '../app')
OUT = os.path.join(HERE, '../public-data')
os.makedirs(OUT, exist_ok=True)
DATE = time.strftime('%Y%m%d')
KIND = ['神社', 'お寺', '滝', '巨樹', '湧き水', '岩', '山', '洞窟']

lineages = {int(m.group(1)): m.group(2) for m in
            re.finditer(r"Lineage\((\d+), '([^']*)'", open(os.path.join(APP, 'lib/data/lineage.dart'), encoding='utf-8').read())}

b = gzip.decompress(open(os.path.join(APP, 'assets/shrines.bin.gz'), 'rb').read())
assert b[:4] == b'RYM2'
n, blob_len, wiki_count, yomi_len = struct.unpack_from('<IIII', b, 4)
o = 20
lat = struct.unpack_from(f'<{n}i', b, o); o += 4 * n
lon = struct.unpack_from(f'<{n}i', b, o); o += 4 * n
lin = b[o:o + n]; o += n
flags = b[o:o + n]; o += n
kind = b[o:o + n]; o += n
noff = struct.unpack_from(f'<{n + 1}I', b, o); o += 4 * (n + 1)
oid = struct.unpack_from(f'<{n}d', b, o); o += 8 * n
nblob = b[o:o + blob_len]; o += blob_len
yoff = struct.unpack_from(f'<{n + 1}I', b, o); o += 4 * (n + 1)
yblob = b[o:o + yomi_len]; o += yomi_len
wiki = {}
for _ in range(wiki_count):
    i, ln = struct.unpack_from('<IH', b, o); o += 6
    wiki[i] = b[o:o + ln].decode('utf-8'); o += ln
assert o == len(b), (o, len(b))

buf = io.StringIO()
w = csv.writer(buf)
w.writerow(['id', 'source', 'kind', 'name', 'yomi', 'lat', 'lon', 'lineage', 'notable', 'unnamed', 'approx_position', 'wikipedia_ja'])
for i in range(n):
    x = oid[i]
    if x >= 1e12:
        rid, src = f'wikidata:Q{int(x - 1e12)}', 'Wikidata (CC0)'
    elif x > 0:
        rid, src = f'osm:node/{int(x)}', 'OpenStreetMap (ODbL)'
    else:
        rid, src = f'osm:way/{int(-x)}', 'OpenStreetMap (ODbL)'
    w.writerow([rid, src, KIND[kind[i]], nblob[noff[i]:noff[i + 1]].decode('utf-8'),
                yblob[yoff[i]:yoff[i + 1]].decode('utf-8'), f'{lat[i] / 1e6:.6f}', f'{lon[i] / 1e6:.6f}',
                lineages.get(lin[i], '') if kind[i] == 0 and lin[i] else '',
                flags[i] & 1 and 1 or 0, flags[i] & 2 and 1 or 0, flags[i] & 4 and 1 or 0, wiki.get(i, '')])
places = os.path.join(OUT, f'ryumyaku-places-{DATE}.csv.gz')
with gzip.open(places, 'wt', encoding='utf-8', newline='') as f:
    f.write(buf.getvalue())

facts = os.path.join(OUT, f'ryumyaku-facts-{DATE}.tsv.gz')
with open(os.path.join(APP, 'assets/facts.tsv.gz'), 'rb') as f:
    open(facts, 'wb').write(f.read())

method = os.path.join(OUT, f'ryumyaku-data-method-{DATE}.zip')
with zipfile.ZipFile(method, 'w', zipfile.ZIP_DEFLATED) as z:
    for name in ['extract_all2.py', 'fetch_wikidata.py', 'fetch_wikidata_facts.py', 'build_all.py', 'build_shrines.py',
                 'export_public.py']:
        p = os.path.join(HERE, name)
        if os.path.exists(p):
            z.write(p, name)
    z.writestr('README.txt', open(os.path.join(HERE, 'public_readme.txt'), encoding='utf-8').read().replace('{DATE}', DATE))

open(os.path.join(OUT, 'README.txt'), 'w', encoding='utf-8').write(
    open(os.path.join(HERE, 'public_readme.txt'), encoding='utf-8').read().replace('{DATE}', DATE))
for p in (places, facts, method):
    print(os.path.basename(p), os.path.getsize(p))
print('rows', n)
