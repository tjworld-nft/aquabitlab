龍脈マップ：場所のデータ（20261107 版）
AquaBit LAB（https://aquabit-lab.com/ryumyaku/data/）

iPhone アプリ「龍脈マップ」に入れている、神社・お寺・自然の場所（滝・巨樹・湧き水・岩・山・洞窟）のデータです。

■ ライセンス
- ryumyaku-places-20261107.csv.gz
  OpenStreetMap のデータから取り出して整えた部分を含むため、Open Database License（ODbL）1.0 で提供します。
  © OpenStreetMap contributors  https://www.openstreetmap.org/copyright
  ODbL の本文：https://opendatacommons.org/licenses/odbl/1-0/
  source 列が「Wikidata (CC0)」の行は、OpenStreetMap に無く Wikidata（CC0）から加えた場所です。
- ryumyaku-facts-20261107.tsv.gz
  Wikidata（CC0）から集めた、まつる神さま・ご本尊・古社の印・創建の年・文化財の区分（アプリの「さらに知る」）。
- ryumyaku-data-method-20261107.zip
  作り方のスクリプト（OpenStreetMap の日本の抽出〈Geofabrik〉から取り出す → Wikidata と照らし合わせる → まとめる）。

■ places の列
  id               osm:node/番号・osm:way/番号・wikidata:Q番号
  source           OpenStreetMap (ODbL) / Wikidata (CC0)
  kind             神社・お寺・滝・巨樹・湧き水・岩・山・洞窟
  name, yomi       名前と読み（読みは分かるものだけ）
  lat, lon         緯度・経度（世界測地系）
  lineage          神社の名前から読み取った「系統」（例：お稲荷さん）。推定であり、由緒を示すものではありません
  notable          Wikipedia・Wikidata の項目があるなど、よく知られた場所なら 1
  unnamed          名前の登録がない場所なら 1
  approx_position  Wikidata だけにある場所（位置が数百mずれていることがある）なら 1
  wikipedia_ja     日本語版ウィキペディアの項目名（分かるものだけ）

■ ご注意
- 位置や名前は、もとのデータのとおりです。まちがいを見つけたら、OpenStreetMap で直していただくと、次の版に入ります。
- 系統は名前からの推定です。祭神・ご利益は神社ごとに異なります。
