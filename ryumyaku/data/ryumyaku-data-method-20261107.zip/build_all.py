"""raw/all2.tsv（extract_all2.py）と raw/wd_*.tsv（fetch_wikidata.py）→ アプリに入れる
assets/shrines.bin.gz（RYM2 形式）を作る。第2版（2026-11-07）。

やること
  1. OpenStreetMap の行を種類に分ける（神社・お寺・滝・巨樹・湧き水・岩・山・洞窟）
     - 神社: 社としての登録（place_of_worship）に加えて、祠（wayside_shrine）や社殿だけの登録も拾う
     - お寺: 名前のあるものすべて。地蔵・石仏のような道ばたの小さなものは入れない
     - 山: 名の知られた山（Wikipedia/Wikidata の項目がある山）だけ
  2. 社殿・堂の一部として登録されたものを外し、点と輪郭の二重登録をまとめる
  3. Wikidata の社寺・名所を重ねる。OSM にあるものは読み・Wikipedia を足すだけ、
     無いものは「位置は目安」の印をつけて加える
© OpenStreetMap contributors（ODbL）／Wikidata（CC0）

RYM2 形式（すべてリトルエンディアン）
  'RYM2' n blobLen wikiCount yomiLen   (u32 ×4)
  lat[n] lon[n]          i32（100万倍した度）
  lineage[n] flags[n] kind[n]   u8   flags: 1=よく知られた 2=名前なし 4=位置は目安（Wikidata）
  nameOff[n+1]           u32
  osmId[n]               f64（点は正、線は -id、Wikidata だけの場所は 1e12 + Q番号）
  nameBlob               UTF-8
  yomiOff[n+1]           u32
  yomiBlob               UTF-8
  wiki × wikiCount       (index u32, len u16, UTF-8)
使い方: python3 build_all.py   （raw/all2.tsv と raw/wd_*.tsv が要る）"""
import csv, struct, gzip, math, collections, sys, unicodedata, os, re
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build_shrines import lineage  # 系統の決まりは一か所に

SHRINE, TEMPLE, FALL, TREE, SPRING, ROCK, MOUNTAIN, CAVE = range(8)
KIND_NAMES = ['神社', 'お寺', '滝', '巨樹', '湧き水', '岩', '山', '洞窟']

DROP_SHRINE = {'手水', '本殿', '拝殿', '舞殿', '幣殿', '神楽殿', '神楽堂', '社務所', '齋館', '斎館', '手水舎', '授与所', '神輿庫', '神輿殿',
               '参集殿', '儀式殿', '絵馬殿', '宝物殿', '神門', '楼門', '鳥居', '社殿', '神饌所', '祓所', '納札所', '古札納所', '参道', '境内',
               '御朱印所', '御札所', '休憩所', 'トイレ', '駐車場'}
DROP_TEMPLE = {'本堂', '山門', '鐘楼', '鐘楼堂', '鐘撞堂', '庫裏', '庫裡', '客殿', '書院', '経蔵', '三重塔', '五重塔', '多宝塔', '観音堂',
               '地蔵堂', '薬師堂', '不動堂', '大師堂', '開山堂', '阿弥陀堂', '仁王門', '総門', '中門', '楼門', '方丈', '講堂', '金堂', '本坊',
               '納骨堂', '位牌堂', '霊廟', '宝物館', '寺務所', '社務所', '墓地', '霊園', '手水舎', '水子地蔵', '六地蔵', '鐘', '本殿', '拝殿'}
BUILDING_SUFFIX = ('拝殿', '本殿', '幣殿', '神楽殿', '神楽堂', '舞殿', '権殿', '社務所', '授与所', '手水舎', '神門', '楼門', '随神門',
                   '鳥居', '絵馬殿', '神饌所', '宝物殿', '参集殿', '祈祷殿', '祈祷所', '奉納所', '神輿庫')
SHRINE_WORDS = ('神社', '宮', '社', '稲荷', '権現', '明神', '祠', '天神', '八幡', '大神', '神')
BUDDHIST_WORDS = ('地蔵', '観音', '不動', '薬師', '大師', '仏', '堂', '寺', '院', '庵', '如来', '菩薩', '尊')
TEMPLE_CORE = ('寺', '院', '庵', '坊')
TEMPLE_HALL_SUFFIX = ('堂', '門', '塔', '楼', '殿', '蔵', '館')
RUIN_WORDS = ('跡', '址', '旧跡', '遺跡', '廃寺')
# 「〇〇神社社務所」「〇〇寺本堂」のような、社寺の建物の名前。末尾を外して本体の名前にし、近くの本体とまとめる
SHRINE_PART_SUFFIX = ('社務所', '社務局', '授与所', '御朱印所', '御札所', '参集殿', '社殿', '拝殿', '本殿', '幣殿', '神楽殿',
                      '神楽堂', '舞殿', '神門', '楼門', '随神門', '鳥居', '手水舎', '宝物殿', '儀式殿', '斎館', '齋館', '祈祷殿')
TEMPLE_PART_SUFFIX = ('本堂', '山門', '庫裏', '庫裡', '鐘楼', '鐘楼堂', '客殿', '書院', '寺務所', '本坊', '仁王門', '総門',
                      '中門', '方丈', '経蔵', '開山堂', '講堂', '金堂', '納骨堂', '位牌堂')
SHRINE_CORE_WORDS = ('神社', '宮', '社', '稲荷', '権現', '明神', '神')
# 新しい宗教の施設や会館は「お寺」「神社」に入れない（参拝先として案内しない）
NOT_TEMPLE = re.compile('創価|佼成|霊友|幸福の科学|真如苑|天理|黒住|金光教|生長の家|阿含|会館|教団|集会所|PL教団|モラロジー')
NOT_SHRINE = re.compile('金光教|天理|黒住教|大本|生長の家|教会|会館|集会所|教団')
# 戦時の壕や坑道は「洞窟」に入れない
NOT_CAVE = re.compile('壕|濠|防空|陣地|砲台|坑|トンネル|隧道|[Mm]ine|地下|エレベーター|入口|出口|入り口|駐車場|料金所|売店')


def norm(s):
    return unicodedata.normalize('NFKC', s or '').strip()


def hira(s):
    s = norm(s).replace(' ', '').replace('・', '').replace('　', '')
    return ''.join(chr(ord(c) - 0x60) if 'ァ' <= c <= 'ヶ' else c for c in s)


VARIANTS = (('龍', '竜'), ('澤', '沢'), ('嶋', '島'), ('嶌', '島'), ('邊', '辺'), ('邉', '辺'), ('國', '国'), ('瀧', '滝'),
            ('櫻', '桜'), ('廣', '広'), ('濱', '浜'), ('龜', '亀'), ('稻', '稲'), ('八旛', '八幡'), ('辨', '弁'), ('辯', '弁'),
            ('嚴', '厳'), ('壽', '寿'), ('與', '与'), ('來', '来'), ('彌', '弥'), ('淺', '浅'), ('戸', '戶'), ('ヶ', 'ケ'),
            ('ヵ', 'カ'), ('之', 'の'), ('ノ', 'の'), ('寳', '宝'), ('寶', '宝'), ('眞', '真'), ('佛', '仏'), ('藏', '蔵'),
            ('圓', '円'), ('德', '徳'), ('證', '証'), ('禪', '禅'), ('靈', '霊'), ('鄕', '郷'), ('惠', '恵'), ('齋', '斎'),
            ('髙', '高'), ('﨑', '崎'), ('嵜', '崎'), ('冨', '富'), ('舘', '館'), ('槇', '槙'), ('觀', '観'), ('萬', '万'),
            ('實', '実'), ('乘', '乗'), ('淨', '浄'), ('瑠', '琉'), ('莊', '荘'), ('豐', '豊'), ('黑', '黒'), ('澁', '渋'),
            ('祐', '佑'), ('神', '神'), ('社', '社'), ('福', '福'), ('祥', '祥'), ('榮', '栄'), ('醫', '医'), ('稻', '稲'),
            ('縣', '県'), ('應', '応'), ('劔', '剣'), ('劒', '剣'), ('の', ''))
CORE_SUFFIX = ('大神社', '神社', '大神宮', '神宮', '大社', '社', '宮', '寺', '院', '庵', '坊', '滝', '大滝', '洞', '洞窟', '鍾乳洞',
               '山', '岳', '岩', '石', '水', '湧水', '清水', '泉', '杉', '桜', '楠', '樟', '大杉', '大楠')


def core(s):
    s = norm(s).replace(' ', '').replace('　', '')
    s = re.sub(r'[（(][^）)]*[）)]$', '', s)
    for a, b in VARIANTS:
        s = s.replace(a, b)
    for suf in CORE_SUFFIX:
        if s.endswith(suf) and len(s) > len(suf):
            s = s[:-len(suf)]
            break
    return s


def full(s):
    """字体だけそろえた名前（末尾の「神社」「神宮」などは残す）"""
    s = norm(s).replace(' ', '').replace('　', '')
    s = re.sub(r'[（(][^）)]*[）)]$', '', s)
    for a, b in VARIANTS:
        s = s.replace(a, b)
    return s


def same_name(a, b):
    ca, cb = core(a), core(b)
    if not ca or not cb:
        return False
    if ca == cb:
        return True
    if min(len(ca), len(cb)) >= 2 and (ca in cb or cb in ca):
        return True
    return False


def dist(a, b):
    return math.hypot((a['lat'] - b['lat']) * 111000, (a['lon'] - b['lon']) * 111000 * math.cos(math.radians(a['lat'])))


def classify(r, name, notable):
    am, rel, hi, bu, na, ww = r['amenity'], r['religion'], r['historic'], r['building'], r['natural'], r['waterway']
    if na == 'tree':
        return TREE
    if ww == 'waterfall':
        return FALL
    if na == 'spring':
        return SPRING
    if na in ('stone', 'rock'):
        return ROCK
    if na == 'cave_entrance':
        return CAVE
    if na == 'peak':
        return MOUNTAIN if notable else None
    if am == 'place_of_worship':
        if rel == 'shinto':
            return SHRINE
        if rel == 'buddhist':
            return TEMPLE if name else None
        if not rel and bu == 'shrine':
            return SHRINE
        return None
    if rel == 'shinto':
        return SHRINE
    if rel == 'buddhist':
        if hi == 'wayside_shrine' or not name:
            return None  # 地蔵・石仏などの小さなもの、名前のない堂
        return TEMPLE
    if bu == 'shrine':
        if name and any(w in name for w in BUDDHIST_WORDS):
            return None
        return SHRINE
    if hi == 'wayside_shrine':
        if name and any(w in name for w in SHRINE_WORDS) and not any(w in name for w in BUDDHIST_WORDS):
            return SHRINE
        return None
    if bu == 'temple':
        return TEMPLE if name else None
    return None


# ---------- 1. OpenStreetMap ----------
SRC = 'raw/all2.tsv'
rows = []
skipped = collections.Counter()
for r in csv.DictReader(open(SRC, encoding='utf-8'), delimiter='\t'):
    lat, lon = float(r['lat']), float(r['lon'])
    if not (20 < lat < 46.5 and 122 < lon < 154.5):
        continue
    name = norm(r['name'])
    wiki = r['wikipedia']
    wt = wiki[3:] if wiki.startswith('ja:') else ''
    notable = bool(r['wikidata'] or wiki or r['denotation'] == 'natural_monument' or r['heritage'])
    k = classify(r, name, notable)
    if k is None:
        skipped['type'] += 1
        continue
    part = False
    orig = name
    if name:
        nm = name.replace('　', ' ').strip()
        if k == SHRINE:
            for suf in SHRINE_PART_SUFFIX:
                base = nm[:-len(suf)].strip(' ・') if nm.endswith(suf) else ''
                if base and any(w in base for w in SHRINE_CORE_WORDS):
                    name, part = base, True
                    break
        elif k == TEMPLE:
            for suf in TEMPLE_PART_SUFFIX:
                base = nm[:-len(suf)].strip(' ・') if nm.endswith(suf) else ''
                if base and any(w in base for w in TEMPLE_CORE):
                    name, part = base, True
                    break
    if k == SHRINE and name in DROP_SHRINE:
        skipped['shrine-part'] += 1
        continue
    # 「外拝殿」「奥社本殿」のような社殿の一部（神社・宮・社 の字を含まないもの）
    if k == SHRINE and name.endswith(BUILDING_SUFFIX) and not any(w in name for w in ('神社', '宮', '社', '稲荷', '権現', '明神')):
        skipped['shrine-part'] += 1
        continue
    if k == TEMPLE and (name in DROP_TEMPLE or any(name.endswith(w) for w in ('墓地', '霊園', '納骨堂', '駐車場'))):
        skipped['temple-part'] += 1
        continue
    if k >= FALL and not name:
        continue
    # 記念植樹などは「巨樹・御神木」に入れない
    if k == TREE and any(w in name for w in ('記念植樹', '記念樹', '植樹')):
        skipped['tree-memorial'] += 1
        continue
    if k == TEMPLE and NOT_TEMPLE.search(name):
        skipped['not-temple'] += 1
        continue
    if k == SHRINE and NOT_SHRINE.search(name):
        skipped['not-shrine'] += 1
        continue
    if k == CAVE and NOT_CAVE.search(name):
        skipped['war-or-mine'] += 1
        continue
    if k in (ROCK, TREE) and '墓' in name:
        skipped['grave'] += 1
        continue
    if name.lower() in ('shrine', 'temple', 'jinja'):
        name = ''
    if k == SPRING and '温泉' in name:
        skipped['onsen'] += 1
        continue
    if len(name) > 40:
        name = name[:40]
    if k == TREE and '神木' in name:
        notable = True
    t = r['type']
    i = int(r['id'])
    oid = float(i) if t == 'n' else -float(i)
    rows.append(dict(kind=k, lat=lat, lon=lon, name=name, wiki=wt, notable=notable, oid=oid, t=t,
                     alt=norm(r['alt']), yomi=hira(r['yomi']), qid=r['wikidata'], approx=False, part=part, orig=orig))
print('building names folded into their shrine/temple', sum(1 for r in rows if r['part']))
print('osm rows', len(rows), collections.Counter(KIND_NAMES[r['kind']] for r in rows), 'skipped', dict(skipped))

# 輪郭（社域・寺域）を先に、名前のあるものを先にまとめる
rows.sort(key=lambda r: (1 if r['part'] else 0, 0 if r['t'] != 'n' else 1, 0 if r['name'] else 1))
grid = collections.defaultdict(list)
out = []


def near(r, lim, cell=0.001):
    cy, cx = int(r['lat'] / cell), int(r['lon'] / cell)
    span = max(1, math.ceil(lim / 75))  # 北の方では経度1区画が短いので広めに
    for dy in range(-span, span + 1):
        for dx in range(-span, span + 1):
            for o in grid[(cy + dy, cx + dx)]:
                d = dist(o, r)
                if d < lim:
                    yield o, d


def add(r):
    grid[(int(r['lat'] / 0.001), int(r['lon'] / 0.001))].append(r)
    out.append(r)


def merge_into(hit, r):
    if not hit['name'] and r['name']:
        hit['name'] = r['name']
    if r['notable']:
        hit['notable'] = True
    if r['wiki'] and not hit['wiki']:
        hit['wiki'] = r['wiki']
    if r['yomi'] and not hit['yomi']:
        hit['yomi'] = r['yomi']
    if r.get('qid') and not hit.get('qid'):
        hit['qid'] = r['qid']


dup = 0
for r in rows:
    hit = None
    k = r['kind']
    lim = 60 if k <= TEMPLE else 120
    if k == SHRINE and not r['name']:
        lim = 100  # 名前のない祠は、近くに社があればその一部とみなす
    if r['part']:
        lim = 300  # 社務所・本堂などは、同じ名前の本体が少し離れていてもまとめる
    for o, d in near(r, lim):
        if o['kind'] != k:
            continue
        if o['name'] == r['name'] or not r['name'] or not o['name'] or (r['part'] and r['name'] in o['name']):
            hit = o
            break
    if hit:
        dup += 1
        merge_into(hit, r)
        continue
    if r['part']:
        # 本体が近くに見つからない社務所・本堂は、元の名前のまま（「〇〇神社社務局」だと分かるように）
        r['name'] = r['orig'][:40]
        r['part'] = False
    add(r)
print('merged dup', dup, '->', len(out))

# お寺の「〜堂」「〜門」で、寺院（〜寺・〜院）のすぐそばにあるものは、その一部とみなす
temples_core = [r for r in out if r['kind'] == TEMPLE and any(w in r['name'] for w in TEMPLE_CORE)]
cgrid = collections.defaultdict(list)
for r in temples_core:
    cgrid[(int(r['lat'] / 0.002), int(r['lon'] / 0.002))].append(r)
drop_ids = set()
for r in out:
    if r['kind'] != TEMPLE or any(w in r['name'] for w in TEMPLE_CORE) or not r['name'].endswith(TEMPLE_HALL_SUFFIX):
        continue
    cy, cx = int(r['lat'] / 0.002), int(r['lon'] / 0.002)
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            for o in cgrid[(cy + dy, cx + dx)]:
                if dist(o, r) < 150:
                    drop_ids.add(id(r))
if drop_ids:
    out = [r for r in out if id(r) not in drop_ids]
    grid.clear()
    for r in out:
        grid[(int(r['lat'] / 0.001), int(r['lon'] / 0.001))].append(r)
print('temple halls inside temples dropped', len(drop_ids))

# 洞窟の「〜口」（秋芳洞黒谷口など）は、近くにある同じ洞窟の入口のひとつ
caves = [r for r in out if r['kind'] == CAVE]
cave_drop = set()
for r in caves:
    if not r['name'].endswith('口'):
        continue
    for o in caves:
        if o is not r and r['name'].startswith(o['name']) and dist(o, r) < 2000:
            cave_drop.add(id(r))
            break
if cave_drop:
    out = [r for r in out if id(r) not in cave_drop]
    grid.clear()
    for r in out:
        grid[(int(r['lat'] / 0.001), int(r['lon'] / 0.001))].append(r)
print('cave side entrances dropped', len(cave_drop))

# ---------- 2. Wikidata ----------
by_qid = {}
for r in out:
    if r.get('qid'):
        by_qid.setdefault(r['qid'], r)

NATURE_CLASS = {
    'Q34038': FALL, 'Q2967706': FALL, 'Q11419632': FALL,
    'Q11479807': TREE, 'Q811534': TREE, 'Q11352785': TREE, 'Q48743901': TREE, 'Q10884': TREE,
    'Q124714': SPRING,
    'Q11444879': ROCK, 'Q8063': ROCK, 'Q327532': ROCK,
    'Q8502': MOUNTAIN, 'Q3393392': MOUNTAIN,
    'Q35509': CAVE, 'Q7558985': CAVE, 'Q27919': CAVE, 'Q1052919': CAVE, 'Q2232001': CAVE, 'Q11665546': CAVE,
}


def wd_rows(path, kind):
    res = []
    for w in csv.DictReader(open(path, encoding='utf-8'), delimiter='\t'):
        if w['ended']:
            continue
        label = norm(w['label'])
        label = re.sub(r'\s*[（(][^）)]*[）)]\s*$', '', label).strip()
        if not label:
            continue
        k = kind
        if k is None:
            ks = [NATURE_CLASS[c] for c in w['classes'].split() if c in NATURE_CLASS]
            if not ks:
                continue
            k = ks[0]
            if k == ROCK and any(x in label for x in ('山', '岳', '峰')):
                k = MOUNTAIN
        if any(label.endswith(x) or x in label for x in RUIN_WORDS):
            continue
        lat, lon = float(w['lat']), float(w['lon'])
        if not (20 < lat < 46.5 and 122 < lon < 154.5):
            continue
        res.append(dict(kind=k, lat=lat, lon=lon, name=label[:40], wiki=w['jawiki'], notable=True,
                        oid=1e12 + int(w['qid'][1:]), t='wd', alt='', yomi=hira(w['kana']), qid=w['qid'], approx=True))
    return res


wd = wd_rows('raw/wd_shrines.tsv', SHRINE) + wd_rows('raw/wd_temples.tsv', TEMPLE) + wd_rows('raw/wd_nature.tsv', None)
added = collections.Counter()
enriched = 0
for w in wd:
    hit = by_qid.get(w['qid'])
    if hit is None:
        k = w['kind']
        name_lim = 2500 if k >= FALL else 1500
        best = None
        for o, d in near(w, name_lim):
            if o['kind'] != k:
                continue
            # 名前がまったく同じ → 少し離れていても同じ社寺。芯だけそろう（「熱田神宮」と「熱田社」）・片方がもう片方を含むだけ
            # （「獅子吼白山比咩神社」と「白山比咩神社」）なら、すぐそばのときだけ
            same = full(o['name']) == full(w['name']) or (d < 300 and same_name(o['name'], w['name']))
            if same and (best is None or d < best[1]):
                best = (o, d)
        if best is None:
            # 名前の登録がない祠・社が、すぐそばにある（Wikidata の名前をつける）
            for o, d in near(w, 150):
                if o['kind'] == k and not o['name'] and (best is None or d < best[1]):
                    best = (o, d)
        hit = best[0] if best else None
    if hit is not None:
        enriched += 1
        if not hit.get('qid'):
            hit['qid'] = w['qid']
        if not hit['yomi'] and w['yomi']:
            hit['yomi'] = w['yomi']
        if not hit['wiki'] and w['wiki']:
            hit['wiki'] = w['wiki']
        hit['notable'] = True
        if not hit['name']:
            hit['name'] = w['name']
        continue
    add(w)
    by_qid[w['qid']] = w
    added[KIND_NAMES[w['kind']]] += 1
print('wikidata', len(wd), 'matched', enriched, 'added', dict(added))

# ---------- 3. 書き出し ----------
out.sort(key=lambda r: (int(r['lat'] / 0.05), int(r['lon'] / 0.05)))
n = len(out)
names = [r['name'].encode('utf-8') for r in out]
blob = b''.join(names)
off = [0]
for b in names:
    off.append(off[-1] + len(b))
yom = [r['yomi'].encode('utf-8') for r in out]
yblob = b''.join(yom)
yoff = [0]
for b in yom:
    yoff.append(yoff[-1] + len(b))
lin = [lineage(r['name'] + ' ' + r['alt']) if r['kind'] == SHRINE else 0 for r in out]
flags = [(1 if r['notable'] else 0) | (2 if not r['name'] else 0) | (4 if r['approx'] else 0) for r in out]
kinds = [r['kind'] for r in out]
wiki = [(i, r['wiki'].encode('utf-8')) for i, r in enumerate(out) if r['wiki']]
assert len({r['oid'] for r in out}) == n, 'id がかぶっています'
buf = bytearray()
buf += b'RYM2' + struct.pack('<IIII', n, len(blob), len(wiki), len(yblob))
buf += struct.pack(f'<{n}i', *[round(r['lat'] * 1e6) for r in out])
buf += struct.pack(f'<{n}i', *[round(r['lon'] * 1e6) for r in out])
buf += bytes(lin) + bytes(flags) + bytes(kinds)
buf += struct.pack(f'<{n + 1}I', *off)
buf += struct.pack(f'<{n}d', *[r['oid'] for r in out])
buf += blob
buf += struct.pack(f'<{n + 1}I', *yoff)
buf += yblob
for i, w in wiki:
    buf += struct.pack('<IH', i, len(w)) + w
with open('raw/built.tsv', 'w', newline='', encoding='utf-8') as fh:  # 確かめ用（アプリには入れない）
    wr = csv.writer(fh, delimiter='\t')
    wr.writerow(['kind', 'lat', 'lon', 'name', 'approx', 'notable', 'qid'])
    for r in out:
        wr.writerow([r['kind'], f"{r['lat']:.6f}", f"{r['lon']:.6f}", r['name'], int(r['approx']), int(r['notable']), r.get('qid') or ''])
# ---------- 4. 学べる材料（Wikidata の祭神・本尊・古社の印・創建・文化財）----------
CLASS_CODES = [('式内社', 'S'), ('論社', 'R'), ('官幣', 'K1'), ('国幣', 'K2'), ('国史見在社', 'H'), ('勅祭社', 'E'),
               ('勅願寺', 'C'), ('霊場', 'J')]
HERITAGE = {'国宝': '国宝', '重要文化財': '重要文化財', '世界遺産の構成資産': '世界遺産の構成資産', '日本国指定史跡': '国の史跡',
            '日本国指定特別史跡': '国の特別史跡', '名勝': '名勝', '特別名勝': '特別名勝', '登録有形文化財': '登録有形文化財'}
wdf = {r['qid']: r for r in csv.DictReader(open('raw/wd_facts.tsv', encoding='utf-8'), delimiter='\t')}
fact_lines = []
for i, r in enumerate(out):
    f = wdf.get(r.get('qid') or '')
    if not f or r['kind'] > TEMPLE:
        continue
    deities = [norm(d) for d in f['deities'].split('|') if d and not re.search(r'(神社|大社|寺|院)$', d)][:4]
    classes = f['classes'].split('|')
    codes = []
    for word, code in CLASS_CODES:
        if any(word in c for c in classes) and code not in codes:
            codes.append(code)
    if 'S' in codes and 'R' in codes:
        codes.remove('R')
    # 神社の印は神社だけ、お寺の印はお寺だけ（Wikidata の取り違えをそのまま出さない）
    codes = [c for c in codes if (c in ('C', 'J')) == (r['kind'] == TEMPLE)]
    year = f['inception'].rstrip('-')
    try:
        year = str(int(year)) if year else ''
    except ValueError:
        year = ''
    her = []
    for h in f['heritage'].split('|'):
        if h in HERITAGE and HERITAGE[h] not in her:
            her.append(HERITAGE[h])
    if deities or codes or year or her:
        fact_lines.append(f"{i}\t{'・'.join(deities)}\t{','.join(codes)}\t{year}\t{'・'.join(her)}")
fdst = '../app/assets/facts.tsv.gz'
gzip.open(fdst, 'wb', compresslevel=9).write(('\n'.join(fact_lines) + '\n').encode('utf-8'))
print('facts', len(fact_lines), 'gz', os.path.getsize(fdst))

dst = '../app/assets/shrines.bin.gz'
gzip.open(dst, 'wb', compresslevel=9).write(bytes(buf))
print('n', n, collections.Counter(KIND_NAMES[k] for k in kinds))
print('raw bytes', len(buf), 'gz', os.path.getsize(dst))
print('notable', sum(1 for f in flags if f & 1), 'unnamed', sum(1 for f in flags if f & 2),
      'approx', sum(1 for f in flags if f & 4), 'wiki', len(wiki), 'yomi', sum(1 for r in out if r['yomi']))
for k in range(1, 8):
    print(KIND_NAMES[k], [r['name'] for r in out if r['kind'] == k][:10])
