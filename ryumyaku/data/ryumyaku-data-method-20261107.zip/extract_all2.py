"""日本の OpenStreetMap 抽出（Geofabrik の japan-latest.osm.pbf）から、
神社・お寺・「パワースポット候補」になりうるものを、なるべく取りこぼさずに取り出す（第2版）。

第1版（extract_all.py）との違い
  - 神社: amenity=place_of_worship だけでなく、religion=shinto の祠（historic=wayside_shrine）や
    building=shrine（社殿だけが描かれている所）も拾う。
  - お寺: Wikipedia/Wikidata の有無にかかわらず、名前のあるものはすべて拾う。
  - 自然: 滝・巨樹・湧き水・岩に加えて、洞窟（natural=cave_entrance）と山（natural=peak）も拾う。
  - どれに分けるかは build_all.py が決める。ここでは判断に使うタグを全部書き出すだけ。
出力: raw/all2.tsv   © OpenStreetMap contributors（ODbL）
使い方: python3 extract_all2.py   （raw/japan.osm.pbf が要る。混んだ Mac で1時間ほど）"""
import osmium, csv, time, collections

SRC = 'raw/japan.osm.pbf'
t0 = time.time()
TAGS = [('religion', 'shinto'), ('religion', 'buddhist'), ('building', 'shrine'), ('building', 'temple'),
        ('historic', 'wayside_shrine'), ('waterway', 'waterfall'), ('natural', 'tree'),
        ('natural', 'spring'), ('natural', 'stone'), ('natural', 'rock'),
        ('natural', 'cave_entrance'), ('natural', 'peak')]
fp = (osmium.FileProcessor(SRC).with_locations()
      .with_filter(osmium.filter.EntityFilter(osmium.osm.NODE | osmium.osm.WAY))
      .with_filter(osmium.filter.TagFilter(*TAGS)))

COLS = ['type', 'id', 'lat', 'lon', 'name', 'alt', 'wikidata', 'wikipedia', 'yomi', 'denotation', 'heritage',
        'name_en', 'amenity', 'religion', 'historic', 'building', 'natural', 'waterway', 'ele']


def yomi(t):
    for k in ('name:ja-Hira', 'name:ja_kana', 'name:ja-Kana', 'name:ja-Hrkt'):
        if t.get(k):
            return t.get(k)
    return ''


def keep(t):
    """書き出すかどうか（分け方は build_all.py）。名前のない木・山・岩は数が多すぎるので落とす。"""
    named = bool(t.get('name') or t.get('name:ja'))
    notable = bool(t.get('wikidata') or t.get('wikipedia') or t.get('heritage')
                   or t.get('denotation') in ('natural_monument', 'landmark'))
    if t.get('religion') in ('shinto', 'buddhist') or t.get('building') in ('shrine', 'temple') \
            or t.get('historic') == 'wayside_shrine':
        return True  # 名前のない祠も、近くに名前のある社がなければ残す（build_all.py）
    return named or notable


rows = []
seen = 0
for o in fp:
    seen += 1
    t = o.tags
    if not keep(t):
        continue
    f = [t.get('name') or t.get('name:ja') or '', t.get('alt_name') or t.get('official_name') or '',
         t.get('wikidata') or '', t.get('wikipedia') or '', yomi(t), t.get('denotation') or '',
         t.get('heritage') or '', t.get('name:en') or '', t.get('amenity') or '', t.get('religion') or '',
         t.get('historic') or '', t.get('building') or '', t.get('natural') or '', t.get('waterway') or '',
         t.get('ele') or '']
    if o.is_node():
        rows.append(('n', o.id, o.location.lat, o.location.lon, *f))
    elif o.is_way():
        la = []
        lo = []
        for n in o.nodes:
            if n.location.valid():
                la.append(n.location.lat)
                lo.append(n.location.lon)
        if not la:
            continue
        rows.append(('w', o.id, (min(la) + max(la)) / 2, (min(lo) + max(lo)) / 2, *f))

with open('raw/all2.tsv', 'w', newline='', encoding='utf-8') as fh:
    wr = csv.writer(fh, delimiter='\t')
    wr.writerow(COLS)
    for x in rows:
        wr.writerow([x[0], x[1], f'{x[2]:.6f}', f'{x[3]:.6f}', *x[4:]])
c = collections.Counter((r[13] or r[15] or r[16] or r[17] or r[14]) for r in rows)
print('seen', seen, 'rows', len(rows), c.most_common(20), round(time.time() - t0), 's')
