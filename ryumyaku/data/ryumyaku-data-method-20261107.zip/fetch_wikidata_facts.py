"""Wikidata（CC0）から、社寺の「学べる」材料を取り出す（2026-11-07）。
  raw/wd_facts.tsv   qid / deities（まつられている神さま・本尊。P825）/ classes（式内社・一宮・旧社格などの種類）
                     / inception（創建の年。P571）/ heritage（文化財の指定。P1435）
使い方: python3 fetch_wikidata_facts.py"""
import csv, json, time, urllib.parse, urllib.request

EP = 'https://query.wikidata.org/sparql'
UA = 'ryumyaku-map-prototype/0.1 (data build; https://miura-diving.com/)'


def run(q, tries=4):
    url = EP + '?' + urllib.parse.urlencode({'query': q, 'format': 'json'})
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers={'User-Agent': UA, 'Accept': 'application/sparql-results+json'})
            with urllib.request.urlopen(req, timeout=300) as r:
                return json.load(r)['results']['bindings']
        except Exception as e:
            print('retry', i, e)
            time.sleep(20 * (i + 1))
    raise SystemExit('wikidata failed')


def val(b, k):
    return b.get(k, {}).get('value', '').replace('http://www.wikidata.org/entity/', '')


facts = {}


def merge(rows, field):
    for b in rows:
        q = val(b, 's')
        v = val(b, 'v')
        if not q or not v:
            continue
        f = facts.setdefault(q, {'deities': [], 'classes': [], 'inception': '', 'heritage': []})
        if field == 'inception':
            if not f['inception']:
                f['inception'] = v[:5].lstrip('+')  # +1063-01-01T… → 1063
        elif v not in f[field]:
            f[field].append(v)


for root in ('Q845945', 'Q5393308'):
    base = f'?s wdt:P31/wdt:P279* wd:{root} ; wdt:P17 wd:Q17 .'
    merge(run(f"""SELECT ?s ?v WHERE {{ {base} ?s wdt:P825 ?x . ?x rdfs:label ?v FILTER(LANG(?v)='ja') }}"""), 'deities')
    merge(run(f"""SELECT ?s ?v WHERE {{ {base} ?s wdt:P31 ?x . ?x rdfs:label ?v FILTER(LANG(?v)='ja') }}"""), 'classes')
    merge(run(f"""SELECT ?s ?v WHERE {{ {base} ?s wdt:P571 ?v . }}"""), 'inception')
    merge(run(f"""SELECT ?s ?v WHERE {{ {base} ?s wdt:P1435 ?x . ?x rdfs:label ?v FILTER(LANG(?v)='ja') }}"""), 'heritage')
    print(root, len(facts))

with open('raw/wd_facts.tsv', 'w', newline='', encoding='utf-8') as fh:
    w = csv.writer(fh, delimiter='\t')
    w.writerow(['qid', 'deities', 'classes', 'inception', 'heritage'])
    for q, f in sorted(facts.items()):
        w.writerow([q, '|'.join(f['deities']), '|'.join(f['classes']), f['inception'], '|'.join(f['heritage'])])
print('wrote', len(facts))
