"""raw/shrines.tsv（OpenStreetMap 抽出）→ アプリに入れる shrines.bin.gz を作る。
- 同じ名前で 60m 以内にある重複（点と輪郭の二重登録）をまとめる
- 名前から「系統」を読み取る（lib/data/lineage.dart の id と対応）
- Wikipedia/Wikidata の項目がある社に「よく知られた社」の印
© OpenStreetMap contributors（ODbL）"""
import csv, struct, gzip, math, re, collections, sys, unicodedata
RULES=[  # (系統id, 名前に含む語)。上から順に見る
 (1,['稲荷','稲生','伏見','いなり']),
 (3,['天満','天神','菅原','北野']),
 (2,['八幡','八旛','宇佐']),
 (4,['神明','天祖','皇大','大神宮','伊勢','天照']),
 (5,['熊野']),
 (6,['春日','鹿島','鹿嶋']),
 (29,['香取']),
 (7,['日吉','日枝','山王']),
 (8,['弁天','辨天','辯天','弁財天','辨財天','厳島','嚴島','厳嶋','市杵島','宗像','銭洗']),
 (9,['出雲','大国','大國','大己貴','大黒']),
 (10,['住吉']),
 (11,['龍神','竜神','龍王','竜王','九頭龍','九頭竜','白龍','龍宮','竜宮','貴船','貴布禰','水神','龗','八大龍','八大竜']),
 (12,['三峯','三峰']),
 (13,['愛宕']),
 (14,['秋葉']),
 (15,['氷川','八坂','祇園','須賀','津島','八雲','素盞','素戔','須佐','牛頭','天王']),
 (16,['諏訪','諏方']),
 (17,['白山']),
 (18,['浅間','淺間','富士']),
 (19,['金刀比羅','琴平','金比羅','金毘羅']),
 (20,['恵比寿','恵比須','恵美須','恵美寿','胡子','蛭子','戎','西宮']),
 (21,['水天宮','子安']),
 (22,['東照']),
 (23,['大鳥','鷲']),
 (24,['山神','山ノ神','山の神','大山祇','大山祗','大山積','三島','三嶋']),
 (25,['猿田彦','白髭','白鬚','道祖']),
 (26,['賀茂','加茂']),
 (27,['淡島','粟島','淡嶋','粟嶋']),
 (28,['護国','護國','招魂']),
 (30,['熱田']),
 (31,['多賀']),
]
def lineage(name):
    for lid,keys in RULES:
        for k in keys:
            if k in name: return lid
    return 0
def _main():
    def norm(s): return unicodedata.normalize('NFKC',s or '').strip()
    # 社殿の一部として登録されているもの（神社そのものではない）
    DROP={'本殿','拝殿','舞殿','幣殿','神楽殿','神楽堂','社務所','齋館','斎館','手水舎','授与所','神輿庫','神輿殿','参集殿','儀式殿','絵馬殿','宝物殿','神門','楼門','鳥居','社殿','神饌所','祓所','納札所','古札納所','参道','境内'}
    rows=[]
    SRC=sys.argv[1] if len(sys.argv)>1 else 'raw/shrines.tsv'
    for r in csv.DictReader(open(SRC,encoding='utf-8'),delimiter='\t'):
        lat,lon=float(r['lat']),float(r['lon'])
        if not (20<lat<46.5 and 122<lon<154.5): continue
        name=norm(r['name'])
        if name in DROP: continue
        if len(name)>40: name=name[:40]
        wiki=r['wikipedia']; wt=''
        if wiki.startswith('ja:'): wt=wiki[3:]
        notable=bool(r['wikidata'] or wiki)
        t=r['type']; i=int(r['id'])
        oid= float(i) if t=='n' else (-float(i) if t=='w' else -(float(i)+1e12))
        rows.append(dict(lat=lat,lon=lon,name=name,wiki=wt,notable=notable,oid=oid,t=t,alt=norm(r['alt'])))
    print('raw',len(rows))
    # 重複をまとめる（同じ名前・60m以内）。輪郭（w/r）を優先。
    rows.sort(key=lambda r:(0 if r['t']!='n' else 1))
    grid=collections.defaultdict(list); out=[]
    def cell(lat,lon): return (int(lat/0.001),int(lon/0.001))
    def dist(a,b):
        return math.hypot((a['lat']-b['lat'])*111000,(a['lon']-b['lon'])*111000*math.cos(math.radians(a['lat'])))
    dup=0
    for r in rows:
        cy,cx=cell(r['lat'],r['lon']); hit=None
        for dy in (-1,0,1):
            for dx in (-1,0,1):
                for o in grid[(cy+dy,cx+dx)]:
                    if dist(o,r)<60 and (o['name']==r['name'] or not r['name'] or not o['name']):
                        hit=o; break
                if hit: break
            if hit: break
        if hit:
            dup+=1
            if not hit['name'] and r['name']: hit['name']=r['name']
            if r['notable']: hit['notable']=True
            if r['wiki'] and not hit['wiki']: hit['wiki']=r['wiki']
            continue
        grid[(cy,cx)].append(r); out.append(r)
    print('merged dup',dup,'->',len(out))
    out.sort(key=lambda r:(int(r['lat']/0.05),int(r['lon']/0.05)))
    n=len(out)
    names=[r['name'].encode('utf-8') for r in out]
    blob=b''.join(names); off=[0]
    for b in names: off.append(off[-1]+len(b))
    lin=[lineage(r['name']+' '+r['alt']) for r in out]
    flags=[(1 if r['notable'] else 0)|(2 if not r['name'] else 0) for r in out]
    wiki=[(i,r['wiki'].encode('utf-8')) for i,r in enumerate(out) if r['wiki']]
    buf=bytearray()
    buf+=b'RYM1'+struct.pack('<III',n,len(blob),len(wiki))
    buf+=struct.pack(f'<{n}i',*[round(r['lat']*1e6) for r in out])
    buf+=struct.pack(f'<{n}i',*[round(r['lon']*1e6) for r in out])
    buf+=bytes(lin)+bytes(flags)
    buf+=struct.pack(f'<{n+1}I',*off)
    buf+=struct.pack(f'<{n}d',*[r['oid'] for r in out])
    buf+=blob
    for i,w in wiki: buf+=struct.pack('<IH',i,len(w))+w
    dst='../app/assets/shrines.bin.gz'
    import os; os.makedirs('../app/assets',exist_ok=True)
    gzip.open(dst,'wb',compresslevel=9).write(bytes(buf))
    print('n',n,'raw bytes',len(buf),'gz',os.path.getsize(dst))
    c=collections.Counter(lin); print('lineage',sorted(c.items(),key=lambda x:-x[1])[:32])
    print('notable',sum(1 for f in flags if f&1),'unnamed',sum(1 for f in flags if f&2),'wiki',len(wiki))
    un=collections.Counter(r['name'] for r,l in zip(out,lin) if l==0 and r['name']); print('unclassified top',un.most_common(40))


if __name__=='__main__':
    _main()
